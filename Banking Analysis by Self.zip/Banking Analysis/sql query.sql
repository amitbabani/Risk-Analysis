Create Database banking_case;
use banking_case;
SHOW TABLES;
select * from customer;

# select*from banking_case.customer;
